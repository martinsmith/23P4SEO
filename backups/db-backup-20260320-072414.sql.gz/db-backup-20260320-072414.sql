-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_user`
--

DROP TABLE IF EXISTS `account_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'owner',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_user_account_id_user_id_unique` (`account_id`,`user_id`),
  KEY `account_user_user_id_foreign` (`user_id`),
  CONSTRAINT `account_user_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_user`
--

LOCK TABLES `account_user` WRITE;
/*!40000 ALTER TABLE `account_user` DISABLE KEYS */;
INSERT INTO `account_user` VALUES (1,1,1,'owner','2026-03-19 10:44:25','2026-03-19 10:44:25');
/*!40000 ALTER TABLE `account_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `billing_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Default Account','free','none','2026-03-19 10:44:25','2026-03-19 10:44:25');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_profiles`
--

DROP TABLE IF EXISTS `business_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_profiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `business_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `primary_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_area_summary` text COLLATE utf8mb4_unicode_ci,
  `target_customer_summary` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `business_profiles_site_id_unique` (`site_id`),
  CONSTRAINT `business_profiles_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_profiles`
--

LOCK TABLES `business_profiles` WRITE;
/*!40000 ALTER TABLE `business_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `business_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_services`
--

DROP TABLE IF EXISTS `business_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `service_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority_order` smallint unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_services_site_id_index` (`site_id`),
  CONSTRAINT `business_services_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_services`
--

LOCK TABLES `business_services` WRITE;
/*!40000 ALTER TABLE `business_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `business_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `competitors`
--

DROP TABLE IF EXISTS `competitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `competitors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `competitors_site_id_index` (`site_id`),
  CONSTRAINT `competitors_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competitors`
--

LOCK TABLES `competitors` WRITE;
/*!40000 ALTER TABLE `competitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `competitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keyword_snapshots`
--

DROP TABLE IF EXISTS `keyword_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keyword_snapshots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tracked_keyword_id` bigint unsigned NOT NULL,
  `checked_at` timestamp NOT NULL,
  `ranking_position` smallint unsigned DEFAULT NULL,
  `found_in_results` tinyint(1) NOT NULL DEFAULT '0',
  `result_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_competitor_domains_json` json DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_result_meta_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `keyword_snapshots_tracked_keyword_id_checked_at_index` (`tracked_keyword_id`,`checked_at`),
  CONSTRAINT `keyword_snapshots_tracked_keyword_id_foreign` FOREIGN KEY (`tracked_keyword_id`) REFERENCES `tracked_keywords` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyword_snapshots`
--

LOCK TABLES `keyword_snapshots` WRITE;
/*!40000 ALTER TABLE `keyword_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `keyword_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2024_01_01_000001_create_accounts_table',2),(5,'2024_01_01_000002_create_sites_table',2),(6,'2024_01_01_000003_create_business_profiles_table',2),(7,'2024_01_01_000004_create_competitors_table',2),(8,'2024_01_01_000005_create_site_integrations_table',2),(9,'2024_01_01_000006_create_scans_table',2),(10,'2024_01_01_000007_create_scan_findings_table',2),(11,'2024_01_01_000008_create_missions_table',2),(12,'2024_01_01_000009_create_validation_tables',2),(13,'2024_01_01_000010_create_keyword_tracking_tables',2),(14,'2024_01_01_000011_create_progress_events_table',2),(15,'2026_03_19_120304_add_resources_json_to_missions_table',3),(16,'2026_03_20_000001_add_source_finding_title_to_missions_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission_tasks`
--

DROP TABLE IF EXISTS `mission_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission_tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `mission_id` bigint unsigned NOT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `task_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_rule_json` json DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mission_tasks_mission_id_index` (`mission_id`),
  CONSTRAINT `mission_tasks_mission_id_foreign` FOREIGN KEY (`mission_id`) REFERENCES `missions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission_tasks`
--

LOCK TABLES `mission_tasks` WRITE;
/*!40000 ALTER TABLE `mission_tasks` DISABLE KEYS */;
INSERT INTO `mission_tasks` VALUES (12,4,1,'Review your robots.txt file for correct syntax','manual',NULL,NULL,'completed',NULL,'2026-03-19 12:09:24','2026-03-19 12:11:59'),(13,4,2,'Ensure it starts with User-agent: followed by Allow/Disallow directives','manual',NULL,NULL,'completed',NULL,'2026-03-19 12:09:24','2026-03-19 12:13:14'),(14,4,3,'Test with Google\'s robots.txt tester in Search Console','manual',NULL,NULL,'pending',NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(15,5,1,'Generate an XML sitemap listing all important pages on your site','manual',NULL,NULL,'pending',NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(16,5,2,'Place the sitemap.xml file at your website root (e.g. yourdomain.com/sitemap.xml)','manual',NULL,NULL,'pending',NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(17,5,3,'Add a Sitemap directive to your robots.txt','manual',NULL,NULL,'pending',NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(18,5,4,'Submit the sitemap in Google Search Console','manual',NULL,NULL,'pending',NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(19,5,5,'Verify the sitemap is accessible','verify',NULL,'{\"check\": \"sitemap_exists\"}','pending',NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(20,6,1,'Open your robots.txt file','manual',NULL,NULL,'completed',NULL,'2026-03-19 12:37:09','2026-03-19 12:38:49'),(21,6,2,'Add a line: Sitemap: https://yourdomain.com/sitemap.xml','manual',NULL,NULL,'completed',NULL,'2026-03-19 12:37:09','2026-03-19 12:38:51'),(22,6,3,'Save and verify the change','verify',NULL,'{\"check\": \"robots_has_sitemap\"}','completed',NULL,'2026-03-19 12:37:09','2026-03-19 12:38:40'),(23,7,1,'Add an og:title meta tag to your homepage <head> section','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(24,7,2,'Add og:description and og:image tags as well for complete social previews','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(25,7,3,'Test with Facebook\'s Sharing Debugger tool','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(26,7,4,'Verify og:title is present','verify',NULL,'{\"check\": \"has_og_title\"}','pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(27,8,1,'Write a concise description (under 200 characters) for social sharing','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(28,8,2,'Add <meta property=\"og:description\" content=\"...\"> to your <head>','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(29,8,3,'Verify og:description is present','verify',NULL,'{\"check\": \"has_og_description\"}','pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(30,9,1,'Create a share image (1200×630 px) representing your brand/site','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(31,9,2,'Upload it to your website and add the og:image meta tag','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(32,9,3,'Verify og:image is present','verify',NULL,'{\"check\": \"has_og_image\"}','pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(33,10,1,'Add twitter:card meta tag (use \"summary_large_image\" for best display)','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(34,10,2,'Add twitter:title, twitter:description, and twitter:image tags','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(35,10,3,'Verify twitter:card is present','verify',NULL,'{\"check\": \"has_twitter_card\"}','pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(36,11,1,'Add a <link rel=\"canonical\"> tag to your homepage <head> pointing to the preferred URL','manual',NULL,NULL,'completed',NULL,'2026-03-20 06:51:37','2026-03-20 06:54:55'),(37,11,2,'Ensure the canonical URL uses HTTPS and your preferred domain format (www or non-www)','manual',NULL,NULL,'completed',NULL,'2026-03-20 06:51:37','2026-03-20 06:54:57'),(38,11,3,'Verify the canonical tag is present','verify',NULL,'{\"check\": \"has_canonical\"}','completed',NULL,'2026-03-20 06:51:37','2026-03-20 06:54:47'),(39,12,1,'Choose the appropriate schema type for your business (LocalBusiness, Organization, etc.)','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(40,12,2,'Create a JSON-LD script block with your business details','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(41,12,3,'Add the <script type=\"application/ld+json\"> block to your homepage <head>','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(42,12,4,'Test with Google\'s Rich Results Test tool','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(43,12,5,'Verify structured data is present','verify',NULL,'{\"check\": \"has_structured_data\"}','pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(44,13,1,'Determine which external resources your site loads (scripts, styles, fonts, images)','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(45,13,2,'Create a CSP policy that allows your required sources','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(46,13,3,'Deploy the header in report-only mode first to test','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(47,13,4,'Switch to enforcing mode once verified','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(48,14,1,'Add X-Content-Type-Options: nosniff to your server configuration','manual',NULL,NULL,'pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(49,14,2,'Verify the header is present','verify',NULL,'{\"check\": \"has_x_content_type_options\"}','pending',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37');
/*!40000 ALTER TABLE `mission_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `missions`
--

DROP TABLE IF EXISTS `missions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `missions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `source_scan_id` bigint unsigned DEFAULT NULL,
  `source_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_finding_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resources_json` json DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'suggested',
  `priority_score` smallint unsigned NOT NULL DEFAULT '50',
  `impact_level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `effort_level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `outcome_statement` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rationale_summary` text COLLATE utf8mb4_unicode_ci,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `activated_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `missions_source_scan_id_foreign` (`source_scan_id`),
  KEY `missions_site_id_status_index` (`site_id`,`status`),
  KEY `missions_site_id_priority_score_index` (`site_id`,`priority_score`),
  CONSTRAINT `missions_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `missions_source_scan_id_foreign` FOREIGN KEY (`source_scan_id`) REFERENCES `site_scans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missions`
--

LOCK TABLES `missions` WRITE;
/*!40000 ALTER TABLE `missions` DISABLE KEYS */;
INSERT INTO `missions` VALUES (4,1,3,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Example: Properly formatted robots.txt\", \"content\": \"User-agent: *\\nAllow: /\\nDisallow: /admin/\\n\\nUser-agent: Googlebot\\nAllow: /\\n\\nSitemap: https://yourdomain.com/sitemap.xml\"}, {\"type\": \"tip\", \"label\": \"Common mistakes\", \"content\": \"Each group must start with a User-agent: line. Directives like Allow: and Disallow: only apply to the User-agent above them. Blank lines separate groups. Comments start with #.\"}, {\"url\": \"https://search.google.com/search-console/robots-testing-tool\", \"type\": \"link\", \"label\": \"Google: robots.txt tester tool\"}, {\"url\": \"https://developers.google.com/search/docs/crawling-indexing/robots/robots_txt\", \"type\": \"link\", \"label\": \"Google: robots.txt specification\"}]','technical','active',45,'medium','low','Your robots.txt contains valid directives','Your robots.txt file exists but doesn\'t contain valid directives. Search engines may ignore it.','An invalid robots.txt can lead to unpredictable crawling behavior.','system',NULL,NULL,'2026-03-19 12:09:24','2026-03-19 12:11:59'),(5,1,3,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Example: A basic sitemap.xml\", \"content\": \"<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\"?>\\n<urlset xmlns=\\\"http://www.sitemaps.org/schemas/sitemap/0.9\\\">\\n  <url>\\n    <loc>https://yourdomain.com/</loc>\\n    <lastmod>2026-01-15</lastmod>\\n    <priority>1.0</priority>\\n  </url>\\n  <url>\\n    <loc>https://yourdomain.com/about</loc>\\n    <lastmod>2026-01-10</lastmod>\\n    <priority>0.8</priority>\\n  </url>\\n</urlset>\"}, {\"type\": \"tip\", \"label\": \"CMS plugins\", \"content\": \"Most CMS platforms have sitemap plugins: Yoast SEO (WordPress), next-sitemap (Next.js), gatsby-plugin-sitemap (Gatsby). These generate and update your sitemap automatically.\"}, {\"url\": \"https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap\", \"type\": \"link\", \"label\": \"Google: Build and submit a sitemap\"}, {\"url\": \"https://www.sitemaps.org/protocol.html\", \"type\": \"link\", \"label\": \"sitemaps.org protocol specification\"}]','technical','suggested',70,'high','medium','Search engines can discover all your pages via an XML sitemap','Your site has no XML sitemap. Without one, search engines must rely on crawling links to find your pages.','An XML sitemap is one of the most effective ways to ensure search engines know about all your important pages.','system',NULL,NULL,'2026-03-19 12:09:24','2026-03-19 12:09:24'),(6,1,4,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Add this line to the end of your robots.txt\", \"content\": \"Sitemap: https://yourdomain.com/sitemap.xml\"}, {\"type\": \"tip\", \"label\": \"Multiple sitemaps\", \"content\": \"You can list multiple sitemaps if you have them, e.g. one per language or content section. Just add a separate Sitemap: line for each.\"}, {\"url\": \"https://developers.google.com/search/docs/crawling-indexing/robots/robots_txt\", \"type\": \"link\", \"label\": \"Google: robots.txt specification\"}]','technical','completed',35,'low','low','Your robots.txt references your sitemap for faster discovery','Your robots.txt does not include a Sitemap directive. Adding one helps search engines find your sitemap faster.','The Sitemap directive in robots.txt is an additional discovery mechanism beyond Search Console submission.','system',NULL,NULL,'2026-03-19 12:37:09','2026-03-19 12:38:51'),(7,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Add these OG tags to your <head>\", \"content\": \"<meta property=\\\"og:title\\\" content=\\\"Your Page Title\\\">\\n<meta property=\\\"og:description\\\" content=\\\"A brief description of your page\\\">\\n<meta property=\\\"og:image\\\" content=\\\"https://yourdomain.com/images/share.jpg\\\">\\n<meta property=\\\"og:url\\\" content=\\\"https://yourdomain.com/\\\">\\n<meta property=\\\"og:type\\\" content=\\\"website\\\">\"}, {\"url\": \"https://developers.facebook.com/tools/debug/\", \"type\": \"link\", \"label\": \"Facebook Sharing Debugger\"}, {\"url\": \"https://ogp.me/\", \"type\": \"link\", \"label\": \"Open Graph Protocol\"}]','social','suggested',45,'medium','low','Your homepage has Open Graph tags for rich social sharing','Your homepage is missing an og:title meta tag. When shared on Facebook or LinkedIn, the preview won\'t have a proper title.','Open Graph tags control how your page appears when shared on social platforms. Without them, platforms guess — often poorly.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(8,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Example og:description tag\", \"content\": \"<meta property=\\\"og:description\\\" content=\\\"We help small businesses grow with expert SEO and web design. Free consultation.\\\">\"}, {\"type\": \"tip\", \"label\": \"Best practice\", \"content\": \"Keep og:description under 200 characters. Make it compelling — this is your pitch when someone shares your link.\"}]','social','suggested',40,'medium','low','Your social shares include a compelling description','Your homepage is missing an og:description tag. Social previews will lack a description.','The og:description controls the snippet text shown in social media previews.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(9,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Example og:image tag\", \"content\": \"<meta property=\\\"og:image\\\" content=\\\"https://yourdomain.com/images/og-share.jpg\\\">\\n<meta property=\\\"og:image:width\\\" content=\\\"1200\\\">\\n<meta property=\\\"og:image:height\\\" content=\\\"630\\\">\"}, {\"type\": \"tip\", \"label\": \"Image size\", \"content\": \"Use 1200×630 pixels for best results across all platforms. Use JPG or PNG format under 8MB.\"}]','social','suggested',50,'high','low','Your social shares display an eye-catching image','Your homepage has no og:image tag. Posts shared on social media will have no image, dramatically reducing engagement.','Social posts with images get significantly more clicks and shares than those without.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(10,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Add Twitter Card tags\", \"content\": \"<meta name=\\\"twitter:card\\\" content=\\\"summary_large_image\\\">\\n<meta name=\\\"twitter:title\\\" content=\\\"Your Page Title\\\">\\n<meta name=\\\"twitter:description\\\" content=\\\"A brief description\\\">\\n<meta name=\\\"twitter:image\\\" content=\\\"https://yourdomain.com/images/share.jpg\\\">\"}, {\"url\": \"https://cards-dev.twitter.com/validator\", \"type\": \"link\", \"label\": \"Twitter Card Validator\"}]','social','suggested',30,'low','low','Your site displays rich previews when shared on X/Twitter','Your homepage lacks a twitter:card meta tag. Shares on X/Twitter won\'t show rich previews.','Twitter Cards enable rich media previews. Without them, links appear as plain text URLs.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(11,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Add a canonical tag to your <head>\", \"content\": \"<link rel=\\\"canonical\\\" href=\\\"https://yourdomain.com/\\\">\"}, {\"type\": \"tip\", \"label\": \"When to use canonical\", \"content\": \"Use canonical tags when the same content is accessible via multiple URLs (www vs non-www, HTTP vs HTTPS, trailing slash variations, query parameters).\"}, {\"url\": \"https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls\", \"type\": \"link\", \"label\": \"Google: Consolidate duplicate URLs\"}]','technical','completed',55,'medium','low','Your homepage specifies a canonical URL to prevent duplicate content','Your homepage does not have a canonical link tag. This can cause duplicate content issues if your page is reachable via multiple URLs.','A canonical tag tells search engines which URL is the \"official\" version of a page, consolidating ranking signals.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:54:57'),(12,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Example: Local Business JSON-LD\", \"content\": \"<script type=\\\"application/ld+json\\\">\\n{\\n  \\\"@context\\\": \\\"https://schema.org\\\",\\n  \\\"@type\\\": \\\"LocalBusiness\\\",\\n  \\\"name\\\": \\\"Your Business Name\\\",\\n  \\\"url\\\": \\\"https://yourdomain.com\\\",\\n  \\\"telephone\\\": \\\"+44 1234 567890\\\",\\n  \\\"address\\\": {\\n    \\\"@type\\\": \\\"PostalAddress\\\",\\n    \\\"streetAddress\\\": \\\"123 Main St\\\",\\n    \\\"addressLocality\\\": \\\"London\\\",\\n    \\\"postalCode\\\": \\\"SW1A 1AA\\\",\\n    \\\"addressCountry\\\": \\\"GB\\\"\\n  }\\n}\\n</script>\"}, {\"url\": \"https://search.google.com/test/rich-results\", \"type\": \"link\", \"label\": \"Google Rich Results Test\"}, {\"url\": \"https://schema.org/docs/gs.html\", \"type\": \"link\", \"label\": \"Schema.org: Getting Started\"}]','technical','suggested',45,'medium','medium','Your homepage uses structured data to enable rich search results','Your homepage has no JSON-LD structured data. Adding schema markup can enable rich results like star ratings, FAQs, and business info in search.','Structured data helps search engines understand your content and can unlock rich result features that increase click-through rates.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(13,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Example basic CSP header\", \"content\": \"Content-Security-Policy: default-src \'self\'; script-src \'self\'; style-src \'self\' \'unsafe-inline\'\"}, {\"url\": \"https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy\", \"type\": \"link\", \"label\": \"MDN: Content-Security-Policy\"}, {\"type\": \"tip\", \"label\": \"Start with report-only\", \"content\": \"Use Content-Security-Policy-Report-Only first to test your policy without breaking anything.\"}]','security','suggested',20,'low','high','Your site uses Content-Security-Policy to prevent XSS attacks','Your site does not send a Content-Security-Policy header. CSP is a defence-in-depth measure against cross-site scripting.','While not a direct ranking factor, security headers build trust and prevent attacks that could compromise your site.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(14,1,9,'scan_finding',NULL,'[{\"type\": \"code\", \"label\": \"Add this header in your server config\", \"content\": \"# Apache (.htaccess)\\nHeader set X-Content-Type-Options \\\"nosniff\\\"\\n\\n# Nginx\\nadd_header X-Content-Type-Options \\\"nosniff\\\" always;\"}]','security','suggested',20,'low','low','Your site sends the X-Content-Type-Options security header','Your site is missing the X-Content-Type-Options: nosniff header, which prevents MIME-type sniffing attacks.','This is a simple security header that prevents browsers from incorrectly interpreting files as different content types.','system',NULL,NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37');
/*!40000 ALTER TABLE `missions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progress_events`
--

DROP TABLE IF EXISTS `progress_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progress_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `event_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `related_mission_id` bigint unsigned DEFAULT NULL,
  `related_keyword_id` bigint unsigned DEFAULT NULL,
  `event_date` date NOT NULL,
  `meta_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `progress_events_related_mission_id_foreign` (`related_mission_id`),
  KEY `progress_events_related_keyword_id_foreign` (`related_keyword_id`),
  KEY `progress_events_site_id_event_date_index` (`site_id`,`event_date`),
  KEY `progress_events_event_type_index` (`event_type`),
  CONSTRAINT `progress_events_related_keyword_id_foreign` FOREIGN KEY (`related_keyword_id`) REFERENCES `tracked_keywords` (`id`) ON DELETE SET NULL,
  CONSTRAINT `progress_events_related_mission_id_foreign` FOREIGN KEY (`related_mission_id`) REFERENCES `missions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `progress_events_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progress_events`
--

LOCK TABLES `progress_events` WRITE;
/*!40000 ALTER TABLE `progress_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `progress_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scan_findings`
--

DROP TABLE IF EXISTS `scan_findings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scan_findings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `site_scan_id` bigint unsigned NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `evidence_json` json DEFAULT NULL,
  `is_blocker` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `first_detected_at` timestamp NULL DEFAULT NULL,
  `last_detected_at` timestamp NULL DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scan_findings_site_id_status_index` (`site_id`,`status`),
  KEY `scan_findings_site_id_category_index` (`site_id`,`category`),
  KEY `scan_findings_site_scan_id_index` (`site_scan_id`),
  CONSTRAINT `scan_findings_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scan_findings_site_scan_id_foreign` FOREIGN KEY (`site_scan_id`) REFERENCES `site_scans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scan_findings`
--

LOCK TABLES `scan_findings` WRITE;
/*!40000 ALTER TABLE `scan_findings` DISABLE KEYS */;
INSERT INTO `scan_findings` VALUES (1,1,1,'technical','robots_txt_invalid','medium','robots.txt exists but appears invalid','The file at /robots.txt was found but does not contain valid robots.txt directives.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"status_code\": 200}',0,'open','2026-03-19 10:59:17','2026-03-19 10:59:17',NULL,'2026-03-19 10:59:17','2026-03-19 10:59:17'),(2,1,1,'technical','sitemap_missing','high','No XML sitemap found','Your site does not have a sitemap.xml file. An XML sitemap helps search engines discover and index your pages.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"status_code\": 404}',0,'open','2026-03-19 10:59:17','2026-03-19 10:59:17',NULL,'2026-03-19 10:59:17','2026-03-19 10:59:17'),(3,1,2,'technical','robots_txt_invalid','medium','robots.txt exists but appears invalid','The file at /robots.txt was found but does not contain valid robots.txt directives.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"status_code\": 200}',0,'open','2026-03-19 11:45:49','2026-03-19 11:45:49',NULL,'2026-03-19 11:45:49','2026-03-19 11:45:49'),(4,1,2,'technical','sitemap_missing','high','No XML sitemap found','Your site does not have a sitemap.xml file. An XML sitemap helps search engines discover and index your pages.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"status_code\": 404}',0,'open','2026-03-19 11:45:49','2026-03-19 11:45:49',NULL,'2026-03-19 11:45:49','2026-03-19 11:45:49'),(5,1,3,'technical','robots_txt_invalid','medium','robots.txt exists but appears invalid','The file at /robots.txt was found but does not contain valid robots.txt directives.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"status_code\": 200}',0,'open','2026-03-19 11:53:38','2026-03-19 11:53:38',NULL,'2026-03-19 11:53:38','2026-03-19 11:53:38'),(6,1,3,'technical','sitemap_missing','high','No XML sitemap found','Your site does not have a sitemap.xml file. An XML sitemap helps search engines discover and index your pages.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"status_code\": 404}',0,'open','2026-03-19 11:53:38','2026-03-19 11:53:38',NULL,'2026-03-19 11:53:38','2026-03-19 11:53:38'),(7,1,4,'technical','robots_txt_found','info','robots.txt exists','Your site has a robots.txt file.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"size_bytes\": 41}',0,'open','2026-03-19 12:37:09','2026-03-19 12:37:09',NULL,'2026-03-19 12:37:09','2026-03-19 12:37:09'),(8,1,4,'technical','robots_txt_no_sitemap','medium','robots.txt does not reference a sitemap','Adding a Sitemap directive to your robots.txt helps search engines discover your sitemap faster.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\"}',0,'open','2026-03-19 12:37:09','2026-03-19 12:37:09',NULL,'2026-03-19 12:37:09','2026-03-19 12:37:09'),(9,1,4,'technical','sitemap_missing','high','No XML sitemap found','Your site does not have a sitemap.xml file. An XML sitemap helps search engines discover and index your pages.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"status_code\": 404}',0,'open','2026-03-19 12:37:09','2026-03-19 12:37:09',NULL,'2026-03-19 12:37:09','2026-03-19 12:37:09'),(10,1,5,'technical','robots_txt_found','info','robots.txt exists','Your site has a robots.txt file.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"size_bytes\": 84}',0,'open','2026-03-19 12:41:54','2026-03-19 12:41:54',NULL,'2026-03-19 12:41:54','2026-03-19 12:41:54'),(11,1,5,'technical','sitemap_found','info','XML sitemap found','Your site has an XML sitemap with approximately 15 URLs.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"type\": \"urlset\", \"url_count\": 15}',0,'open','2026-03-19 12:41:54','2026-03-19 12:41:54',NULL,'2026-03-19 12:41:54','2026-03-19 12:41:54'),(12,1,6,'technical','robots_txt_found','info','robots.txt exists','Your site has a robots.txt file.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"size_bytes\": 84}',0,'open','2026-03-19 13:40:03','2026-03-19 13:40:03',NULL,'2026-03-19 13:40:03','2026-03-19 13:40:03'),(13,1,6,'technical','sitemap_found','info','XML sitemap found','Your site has an XML sitemap with approximately 15 URLs.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"type\": \"urlset\", \"url_count\": 15}',0,'open','2026-03-19 13:40:03','2026-03-19 13:40:03',NULL,'2026-03-19 13:40:03','2026-03-19 13:40:03'),(17,3,8,'technical','robots_txt_found','info','robots.txt exists','Your site has a robots.txt file.','{\"url\": \"https://hair-haven.uk/robots.txt\", \"size_bytes\": 258}',0,'open','2026-03-19 13:41:57','2026-03-19 13:41:57',NULL,'2026-03-19 13:41:57','2026-03-19 13:41:57'),(18,3,8,'technical','sitemap_found','info','XML sitemap found','Your site has a sitemap index file, which links to other sitemaps.','{\"url\": \"https://hair-haven.uk/sitemap.xml\", \"type\": \"index\", \"url_count\": 0}',0,'open','2026-03-19 13:41:57','2026-03-19 13:41:57',NULL,'2026-03-19 13:41:57','2026-03-19 13:41:57'),(19,1,9,'technical','robots_txt_found','info','robots.txt exists','Your site has a robots.txt file.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"size_bytes\": 87}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(20,1,9,'technical','sitemap_found','info','XML sitemap found','Your site has an XML sitemap with approximately 15 URLs.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"type\": \"urlset\", \"url_count\": 15}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(21,1,9,'social','missing_og_title','medium','Missing Open Graph title (og:title)','Your homepage does not have an og:title meta tag. When shared on Facebook, LinkedIn, or other platforms, the preview may look incomplete or use auto-generated text.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(22,1,9,'social','missing_og_description','medium','Missing Open Graph description (og:description)','Your homepage is missing an og:description tag. Social shares will lack a compelling description preview.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(23,1,9,'social','missing_og_image','medium','Missing Open Graph image (og:image)','Your homepage has no og:image tag. Social shares will have no image preview, which significantly reduces engagement and click-through rates.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(24,1,9,'social','missing_twitter_card','low','Missing Twitter Card meta tag','Your homepage does not have a twitter:card meta tag. X/Twitter shares won\'t display rich previews.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(25,1,9,'technical','missing_canonical','medium','Missing canonical URL tag','Your homepage does not specify a canonical URL. This can lead to duplicate content issues if your page is accessible at multiple URLs.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(26,1,9,'technical','missing_structured_data','medium','No JSON-LD structured data found','Your homepage has no JSON-LD structured data. Adding schema markup helps search engines understand your business and can enable rich results (star ratings, FAQs, breadcrumbs).','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(27,1,9,'security','missing_csp_header','low','Missing Content-Security-Policy header','Your site does not send a Content-Security-Policy (CSP) header. CSP helps prevent cross-site scripting (XSS) and data injection attacks.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(28,1,9,'security','missing_x_content_type_options','low','Missing X-Content-Type-Options header','Your site does not send the X-Content-Type-Options: nosniff header. This header prevents browsers from MIME-type sniffing.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 06:51:37','2026-03-20 06:51:37',NULL,'2026-03-20 06:51:37','2026-03-20 06:51:37'),(29,1,10,'technical','robots_txt_found','info','robots.txt exists','Your site has a robots.txt file.','{\"url\": \"https://altiuslifts.co.uk/robots.txt\", \"size_bytes\": 87}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(30,1,10,'technical','sitemap_found','info','XML sitemap found','Your site has an XML sitemap with approximately 15 URLs.','{\"url\": \"https://altiuslifts.co.uk/sitemap.xml\", \"type\": \"urlset\", \"url_count\": 15}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(31,1,10,'social','missing_og_title','medium','Missing Open Graph title (og:title)','Your homepage does not have an og:title meta tag. When shared on Facebook, LinkedIn, or other platforms, the preview may look incomplete or use auto-generated text.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(32,1,10,'social','missing_og_description','medium','Missing Open Graph description (og:description)','Your homepage is missing an og:description tag. Social shares will lack a compelling description preview.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(33,1,10,'social','missing_og_image','medium','Missing Open Graph image (og:image)','Your homepage has no og:image tag. Social shares will have no image preview, which significantly reduces engagement and click-through rates.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(34,1,10,'social','missing_twitter_card','low','Missing Twitter Card meta tag','Your homepage does not have a twitter:card meta tag. X/Twitter shares won\'t display rich previews.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(35,1,10,'technical','missing_structured_data','medium','No JSON-LD structured data found','Your homepage has no JSON-LD structured data. Adding schema markup helps search engines understand your business and can enable rich results (star ratings, FAQs, breadcrumbs).','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(36,1,10,'security','missing_csp_header','low','Missing Content-Security-Policy header','Your site does not send a Content-Security-Policy (CSP) header. CSP helps prevent cross-site scripting (XSS) and data injection attacks.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43'),(37,1,10,'security','missing_x_content_type_options','low','Missing X-Content-Type-Options header','Your site does not send the X-Content-Type-Options: nosniff header. This header prevents browsers from MIME-type sniffing.','{\"url\": \"https://altiuslifts.co.uk/\"}',0,'open','2026-03-20 07:08:43','2026-03-20 07:08:43',NULL,'2026-03-20 07:08:43','2026-03-20 07:08:43');
/*!40000 ALTER TABLE `scan_findings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('9BHrRBfsFPmM30HR9UnT5cNom8zmmFiV3LQJ9Zot',NULL,'192.168.97.5','curl/8.7.1','eyJfdG9rZW4iOiJWRVM3YlBsV09BWnk2alRzSHBWeTBlWVZ4NkJzT2k5Nzkzc0cwaGZ3IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8yM3A0LmRkZXYuc2l0ZVwvc2l0ZXNcLzEiLCJyb3V0ZSI6InNpdGVzLnNob3cifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1773989312),('bi4P44ghUOHjIuz88iG6quSgXl3meoBAQOMac7Re',NULL,'192.168.97.5','curl/8.7.1','eyJfdG9rZW4iOiJNMlkyd0ZlQWk4UTBKVE9GQUFUUGhGSXRZSldjc0N0YXJhWWVPQUtjIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8yM3A0LmRkZXYuc2l0ZVwvc2l0ZXMiLCJyb3V0ZSI6InNpdGVzLmluZGV4In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1773989312),('mg0EXKQjdgCe66nYFY7Ayffed9NZMLDBzQg7LI3T',NULL,'192.168.97.5','curl/8.7.1','eyJfdG9rZW4iOiJ3cVRjZzZXaDE5bjdmRXVUSkZPdXdHN1RXSW5hZmVmdUhVNGt6ZEpqIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8yM3A0LmRkZXYuc2l0ZSIsInJvdXRlIjoiZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1773989312),('oP58gYav7X7rZdLQyogZggGFLRcK8bKeaXhFW9g7',NULL,'192.168.97.5','curl/8.7.1','eyJfdG9rZW4iOiJTeVRYcXY5ZEh4MzBsRVFSWnNNVHNNNW8ycmQ4STJtUnMwaEN3eEFZIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8yM3A0LmRkZXYuc2l0ZVwvc2l0ZXMiLCJyb3V0ZSI6InNpdGVzLmluZGV4In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1773989312),('UZBJYTsBCjws3mFJbLIYIZtzmPQzTOIf2HYVmFNx',NULL,'192.168.97.5','curl/8.7.1','eyJfdG9rZW4iOiJNVFFLUEFSOUtGV1BpOWJDOERHRXB3NVREN0xhVW04QXlIWFg3T3dFIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8yM3A0LmRkZXYuc2l0ZSIsInJvdXRlIjoiZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1773989312),('Zjp7rZ2QUcUHlsowT6QSSEDM8y0ZHk7dKz5uD1Z0',NULL,'192.168.97.5','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJqSENCV3BqUVlpaThFaG1Dd2hIZzFWSWZEOVF6WVV0QlREYXduMUk4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC8yM3A0LmRkZXYuc2l0ZSIsInJvdXRlIjoiZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1773991385);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_integrations`
--

DROP TABLE IF EXISTS `site_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_integrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_connected',
  `external_account_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_property_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connected_at` timestamp NULL DEFAULT NULL,
  `last_synced_at` timestamp NULL DEFAULT NULL,
  `meta_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_integrations_site_id_provider_index` (`site_id`,`provider`),
  CONSTRAINT `site_integrations_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_integrations`
--

LOCK TABLES `site_integrations` WRITE;
/*!40000 ALTER TABLE `site_integrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_pages`
--

DROP TABLE IF EXISTS `site_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `site_scan_id` bigint unsigned NOT NULL,
  `url` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_code` smallint unsigned DEFAULT NULL,
  `canonical_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_indexable` tinyint(1) NOT NULL DEFAULT '1',
  `is_noindex` tinyint(1) NOT NULL DEFAULT '0',
  `last_seen_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_pages_site_id_index` (`site_id`),
  KEY `site_pages_site_scan_id_index` (`site_scan_id`),
  CONSTRAINT `site_pages_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `site_pages_site_scan_id_foreign` FOREIGN KEY (`site_scan_id`) REFERENCES `site_scans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_pages`
--

LOCK TABLES `site_pages` WRITE;
/*!40000 ALTER TABLE `site_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_scans`
--

DROP TABLE IF EXISTS `site_scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_scans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `scan_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'queued',
  `scan_version` int unsigned NOT NULL DEFAULT '1',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `summary_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_scans_site_id_status_index` (`site_id`,`status`),
  CONSTRAINT `site_scans_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_scans`
--

LOCK TABLES `site_scans` WRITE;
/*!40000 ALTER TABLE `site_scans` DISABLE KEYS */;
INSERT INTO `site_scans` VALUES (1,1,'full','completed',1,'2026-03-19 10:59:16','2026-03-19 10:59:17','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.38}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.66}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.18}}, \"blockers\": 0, \"total_findings\": 2, \"severity_counts\": {\"high\": 1, \"medium\": 1}}','2026-03-19 10:59:16','2026-03-19 10:59:17'),(2,1,'full','completed',1,'2026-03-19 11:45:48','2026-03-19 11:45:49','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.35}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.82}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.17}}, \"blockers\": 0, \"total_findings\": 2, \"severity_counts\": {\"high\": 1, \"medium\": 1}}','2026-03-19 11:45:48','2026-03-19 11:45:49'),(3,1,'full','completed',1,'2026-03-19 11:53:37','2026-03-19 11:53:38','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.39}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.69}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.2}}, \"blockers\": 0, \"total_findings\": 2, \"severity_counts\": {\"high\": 1, \"medium\": 1}}','2026-03-19 11:53:37','2026-03-19 11:53:38'),(4,1,'full','completed',1,'2026-03-19 12:37:08','2026-03-19 12:37:09','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.32}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.7}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 2, \"elapsed_seconds\": 0.14}}, \"blockers\": 0, \"total_findings\": 3, \"severity_counts\": {\"high\": 1, \"info\": 1, \"medium\": 1}}','2026-03-19 12:37:08','2026-03-19 12:37:09'),(5,1,'full','completed',1,'2026-03-19 12:41:53','2026-03-19 12:41:54','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.15}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.8}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.16}}, \"blockers\": 0, \"total_findings\": 2, \"severity_counts\": {\"info\": 2}}','2026-03-19 12:41:53','2026-03-19 12:41:54'),(6,1,'full','completed',1,'2026-03-19 13:40:02','2026-03-19 13:40:03','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.15}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 1}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.42}}, \"blockers\": 0, \"total_findings\": 2, \"severity_counts\": {\"info\": 2}}','2026-03-19 13:40:02','2026-03-19 13:40:03'),(8,3,'full','completed',1,'2026-03-19 13:41:56','2026-03-19 13:41:57','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.28}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.62}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.57}}, \"blockers\": 0, \"total_findings\": 2, \"severity_counts\": {\"info\": 2}}','2026-03-19 13:41:56','2026-03-19 13:41:57'),(9,1,'full','completed',1,'2026-03-20 06:51:34','2026-03-20 06:51:37','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.11}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.75}, \"Security\": {\"status\": \"completed\", \"findings_count\": 2, \"elapsed_seconds\": 0.57}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.15}, \"Technical SEO\": {\"status\": \"completed\", \"findings_count\": 2, \"elapsed_seconds\": 0.61}, \"Meta Tags & Social\": {\"status\": \"completed\", \"findings_count\": 4, \"elapsed_seconds\": 0.72}}, \"blockers\": 0, \"total_findings\": 10, \"severity_counts\": {\"low\": 3, \"info\": 2, \"medium\": 5}}','2026-03-20 06:51:34','2026-03-20 06:51:37'),(10,1,'full','completed',1,'2026-03-20 07:08:40','2026-03-20 07:08:43','{\"checks\": {\"Sitemap\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.11}, \"Homepage\": {\"status\": \"completed\", \"findings_count\": 0, \"elapsed_seconds\": 0.67}, \"Security\": {\"status\": \"completed\", \"findings_count\": 2, \"elapsed_seconds\": 0.62}, \"Robots.txt\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.14}, \"Technical SEO\": {\"status\": \"completed\", \"findings_count\": 1, \"elapsed_seconds\": 0.61}, \"Meta Tags & Social\": {\"status\": \"completed\", \"findings_count\": 4, \"elapsed_seconds\": 0.72}}, \"blockers\": 0, \"total_findings\": 9, \"severity_counts\": {\"low\": 3, \"info\": 2, \"medium\": 4}}','2026-03-20 07:08:40','2026-03-20 07:08:43');
/*!40000 ALTER TABLE `site_scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint unsigned NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primary_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primary_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `onboarding_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_scan',
  `lifecycle_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'setup',
  `last_scanned_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sites_account_id_index` (`account_id`),
  KEY `sites_normalized_domain_index` (`normalized_domain`),
  CONSTRAINT `sites_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,'altiuslifts.co.uk','https://altiuslifts.co.uk','altiuslifts.co.uk',NULL,'scanned','setup',NULL,'2026-03-19 10:51:12','2026-03-19 10:59:17'),(3,1,'hair-haven.uk','https://hair-haven.uk','hair-haven.uk',NULL,'scanned','setup',NULL,'2026-03-19 13:41:54','2026-03-19 13:41:57');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracked_keywords`
--

DROP TABLE IF EXISTS `tracked_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tracked_keywords` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intent_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'service',
  `priority_order` smallint unsigned NOT NULL DEFAULT '0',
  `target_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tracked_keywords_site_id_status_index` (`site_id`,`status`),
  CONSTRAINT `tracked_keywords_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracked_keywords`
--

LOCK TABLES `tracked_keywords` WRITE;
/*!40000 ALTER TABLE `tracked_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `tracked_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@23p4.local','2026-03-19 10:44:24','$2y$12$xccv/qqfdd4qyzCzHvXgouWEcuXOs.ieWPgO/y8kJITa26ZEPU7iO','y37Ojuf2pP','2026-03-19 10:44:25','2026-03-19 10:44:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validation_checks`
--

DROP TABLE IF EXISTS `validation_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validation_checks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `validation_run_id` bigint unsigned NOT NULL,
  `mission_task_id` bigint unsigned DEFAULT NULL,
  `check_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `evidence_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `validation_checks_mission_task_id_foreign` (`mission_task_id`),
  KEY `validation_checks_validation_run_id_index` (`validation_run_id`),
  CONSTRAINT `validation_checks_mission_task_id_foreign` FOREIGN KEY (`mission_task_id`) REFERENCES `mission_tasks` (`id`) ON DELETE SET NULL,
  CONSTRAINT `validation_checks_validation_run_id_foreign` FOREIGN KEY (`validation_run_id`) REFERENCES `validation_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validation_checks`
--

LOCK TABLES `validation_checks` WRITE;
/*!40000 ALTER TABLE `validation_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `validation_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validation_runs`
--

DROP TABLE IF EXISTS `validation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validation_runs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `mission_id` bigint unsigned DEFAULT NULL,
  `triggered_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'queued',
  `summary` text COLLATE utf8mb4_unicode_ci,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `validation_runs_mission_id_foreign` (`mission_id`),
  KEY `validation_runs_site_id_status_index` (`site_id`,`status`),
  CONSTRAINT `validation_runs_mission_id_foreign` FOREIGN KEY (`mission_id`) REFERENCES `missions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `validation_runs_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validation_runs`
--

LOCK TABLES `validation_runs` WRITE;
/*!40000 ALTER TABLE `validation_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `validation_runs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-20  7:24:17
